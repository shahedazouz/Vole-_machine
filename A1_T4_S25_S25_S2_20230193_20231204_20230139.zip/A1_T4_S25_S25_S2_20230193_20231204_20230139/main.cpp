#include "header.h"
#include <bits/stdc++.h>
using namespace std;
int main() {
    memory memoryObj;
    Register registerObj;
    CPU cpu(registerObj, memoryObj);
    cout<<"welcome to vole machine \n enter the file name : ";
    string filename;
    cin>>filename;
    memoryObj.loadProgramFile(filename);
    for(int i=0;i<1;i++) {
        cpu.execute();
        cout<<"output screen:\n";
        if (memoryObj.getCell(0) != "00") {
            string hexValue = memoryObj.getCell(0); // Get the value in hexadecimal
            int decimalValue = stoi(hexValue, nullptr, 16) ;// Convert to decimal
            char c=static_cast<char>(decimalValue);
            cout << "hex:" << hexValue<<"\n"<<"ascii:"<<c<<"\n"; // Output in hexa and ascii
        }
    }
    memoryObj.outputMemory(memoryObj);
    registerObj.outputRegister(registerObj);

    return 0;
}